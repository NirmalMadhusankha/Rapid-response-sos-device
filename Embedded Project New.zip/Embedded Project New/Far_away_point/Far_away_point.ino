#include <SPI.h>
#include <LoRa.h>

// ===== LoRa Pins =====
#define SS 10
#define RST 9
#define DIO0 2

// ===== LEDs =====
#define LED_NORMAL 4
#define LED_FLOOD 5
#define LED_LANDSLIDE 6

String receivedMsg = "";

// ===== Setup =====
void setup() {
  Serial.begin(9600);

  pinMode(LED_NORMAL, OUTPUT);
  pinMode(LED_FLOOD, OUTPUT);
  pinMode(LED_LANDSLIDE, OUTPUT);

  // Initialize LoRa
  LoRa.setPins(SS, RST, DIO0);

  if (!LoRa.begin(433E6)) {
    Serial.println(" LoRa init failed!");
    while (1);
  }

  Serial.println(" FAR UNIT READY (LoRa Receiver)");
}

// ===== Loop =====
void loop() {

  int packetSize = LoRa.parsePacket();

  if (packetSize) {

    receivedMsg = "";

    while (LoRa.available()) {
      receivedMsg += (char)LoRa.read();
    }

    // ===== Print in ONE LINE (easy debug) =====
    Serial.print("Received Status: ");
    Serial.println(receivedMsg);

    // ===== Reset LEDs =====
    digitalWrite(LED_NORMAL, LOW);
    digitalWrite(LED_FLOOD, LOW);
    digitalWrite(LED_LANDSLIDE, LOW);

    // ===== Decision =====
    if (receivedMsg == "NORMAL") {
      digitalWrite(LED_NORMAL, HIGH);
    }
    else if (receivedMsg == "FLOOD") {
      digitalWrite(LED_FLOOD, HIGH);
    }
    else if (receivedMsg == "LANDSLIDE") {
      digitalWrite(LED_LANDSLIDE, HIGH);
    }
    else {
      Serial.println("
       Unknown data received!");
    }
  }
}