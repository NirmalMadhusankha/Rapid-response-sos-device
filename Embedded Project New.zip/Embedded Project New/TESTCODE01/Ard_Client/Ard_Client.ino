#include <SoftwareSerial.h>

SoftwareSerial esp(2, 3);

void setup() {
  Serial.begin(9600);
  esp.begin(9600);
}

void loop() {
  if (esp.available()) {
    String msg = esp.readStringUntil('\n');
    Serial.println("Received: " + msg);
  }
}