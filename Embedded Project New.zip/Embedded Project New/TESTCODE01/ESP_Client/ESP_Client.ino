#include <ESP8266WiFi.h>

const char* ssid = "Nirmal's iphone";
const char* pass = "12345678";

IPAddress server(192,168,1,4); // CHANGE to your server IP

WiFiClient client;

void setup() {
  Serial.begin(9600);

  WiFi.begin(ssid, pass);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }

  Serial.println("Connected");
}

void loop() {
  if (client.connect(server, 80)) {
    String msg = client.readStringUntil('\n');
    Serial.println(msg);
    client.stop();
  }

  delay(2000);
}