#include <ESP8266WiFi.h>

const char* ssid = "Nirmal's iphone";
const char* pass = "12345678";

WiFiServer server(80);

void setup() {
  Serial.begin(9600);
  
  WiFi.begin(ssid, pass);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }

  Serial.println("Connected");
  Serial.println(WiFi.localIP());

  server.begin();
}

void loop() {
  WiFiClient client = server.available();

  if (client) {
    String data = Serial.readStringUntil('\n'); // read full line
    client.println(data);  // send full message
    client.stop();
  }
}