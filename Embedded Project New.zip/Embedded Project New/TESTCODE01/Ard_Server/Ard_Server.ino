#include <SoftwareSerial.h>

SoftwareSerial esp(2, 3); // RX, TX

void setup() {
  Serial.begin(9600);
  esp.begin(9600);
}

void loop() {
  esp.println("Hello");
  Serial.println("Sent: Hello");
  delay(2000);
}