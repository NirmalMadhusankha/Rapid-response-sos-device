#include <SoftwareSerial.h>

SoftwareSerial esp(2, 3);

void sendCommand(String cmd, int delayTime = 2000) {
  Serial.println(">> " + cmd);
  esp.println(cmd);

  long int time = millis();
  while ((time + delayTime) > millis()) {
    while (esp.available()) {
      Serial.write(esp.read());
    }
  }
  Serial.println("\n------------------");
}

void setup() {
  Serial.begin(9600);
  esp.begin(115200);

  Serial.println("CLIENT START");

  sendCommand("AT");
  sendCommand("AT+CWMODE=1");

  // Connect to server WiFi
  sendCommand("AT+CWJAP=\"ESP_SERVER\",\"12345678\"");

  Serial.println("CLIENT READY");
}

void loop() {

  // Connect to server
  esp.println("AT+CIPSTART=\"TCP\",\"192.168.4.1\",80");
  delay(2000);

  // Message to send
  String msg = "hey how are you";

  // Send message length
  esp.print("AT+CIPSEND=");
  esp.println(msg.length());
  delay(1000);

  // Send actual message
  esp.print(msg);

  delay(5000);
}