#include <SoftwareSerial.h>

SoftwareSerial esp(2, 3);

void sendCommand(String cmd, int delayTime = 2000) {
  Serial.println(">> " + cmd);
  esp.println(cmd);

  long int time = millis();
  while ((time + delayTime) > millis()) {
    while (esp.available()) {
      Serial.write(esp.read());
    }
  }
  Serial.println("\n------------------");
}

void setup() {
  Serial.begin(9600);
  esp.begin(115200);

  Serial.println("SERVER START");
  sendCommand("AT");
  sendCommand("AT+CWMODE=2");  // AP mode
  sendCommand("AT+CWSAP=\"ESP_SERVER\",\"12345678\",5,3"); // create WiFi
  sendCommand("AT+CIPMUX=1");
  sendCommand("AT+CIPSERVER=1,80");
  sendCommand("AT+CIFSR"); // should show 192.168.4.1
  Serial.println("SERVER READY");
}

void loop() {
  if (esp.available()) {
    String data = esp.readString();

    // Check if data contains incoming message
    if (data.indexOf("+IPD") != -1) {

      int start = data.indexOf(":") + 1;
      String message = data.substring(start);

      Serial.println("Received Message:");
      Serial.println(message);
    }
  }
}