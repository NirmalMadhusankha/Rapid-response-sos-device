#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_ADXL345_U.h>

Adafruit_ADXL345_Unified accel = Adafruit_ADXL345_Unified(12345);

// Accelerometer
float x0, y0, z0;
float accelThreshold = 0.5;
bool L1 = false;

// Water sensor
int waterPin = A0;
int waterValue = 0;
int waterThreshold = 400;  // adjust this after testing
bool F1 = false;

void setup(void) {
  Serial.begin(9600);

  if (!accel.begin()) {
    Serial.println("No ADXL345 detected!");
    while (1);
  }

  accel.setRange(ADXL345_RANGE_16_G);

  Serial.println("Calibrating accelerometer...");
  delay(2000);

  sensors_event_t event;
  accel.getEvent(&event);

  x0 = event.acceleration.x;
  y0 = event.acceleration.y;
  z0 = event.acceleration.z;

  Serial.println("System Ready!");
}

void loop(void) {

  // --------- Accelerometer (L1) ---------
  sensors_event_t event;
  accel.getEvent(&event);

  float x = event.acceleration.x;
  float y = event.acceleration.y;
  float z = event.acceleration.z;

  float dx = abs(x - x0);
  float dy = abs(y - y0);
  float dz = abs(z - z0);

  if (dx > accelThreshold || dy > accelThreshold || dz > accelThreshold) {
    L1 = true;
  } else {
    L1 = false;
  }

  // --------- Water Sensor (F1) ---------
  waterValue = analogRead(waterPin);

  if (waterValue > waterThreshold) {
    F1 = true;   // Flood detected
  } else {
    F1 = false;
  }

  // --------- Serial Output ---------
  Serial.print("X: "); Serial.print(x);
  Serial.print(" Y: "); Serial.print(y);
  Serial.print(" Z: "); Serial.print(z);

  Serial.print(" | L1: "); Serial.print(L1);

  Serial.print(" | Water: "); Serial.print(waterValue);
  Serial.print(" | F1: "); Serial.print(F1);

  if (L1) {
    Serial.print(" >>> Landslide!");
  }

  if (F1) {
    Serial.print(" >>> Flood!");
  }

  Serial.println();

  delay(500);
}