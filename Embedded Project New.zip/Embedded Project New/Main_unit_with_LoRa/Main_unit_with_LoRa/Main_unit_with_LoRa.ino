#include <Wire.h>
#include <SPI.h>
#include <LoRa.h>

// ===== LoRa Pins =====
#define SS 10
#define RST 9
#define DIO0 2

// ===== Water Sensor =====
#define WATER_SENSOR A0
#define WATER_THRESHOLD 700

// ===== ADXL345 =====
#define ADXL345_ADDR 0x53

float ax, ay, az;
float ax0, ay0, az0;

String statusMsg = "NORMAL";

// ===== ESP8266 (WiFi) =====
// Use same Serial you used before OR SoftwareSerial
// Example (adjust if needed):
#include <SoftwareSerial.h>
SoftwareSerial esp(6, 7); // RX, TX

// ===== Read Accelerometer =====
void readAccelerometer() {
  Wire.beginTransmission(ADXL345_ADDR);
  Wire.write(0x32);
  Wire.endTransmission(false);
  Wire.requestFrom(ADXL345_ADDR, 6, true);

  ax = (int16_t)(Wire.read() | Wire.read() << 8);
  ay = (int16_t)(Wire.read() | Wire.read() << 8);
  az = (int16_t)(Wire.read() | Wire.read() << 8);
}

// ===== Send via WiFi (KEEP YOUR OLD LOGIC HERE) =====
void sendWiFi(String msg) {
  // Replace this with your previous working ESP8266 code

  esp.println(msg);   // simple example
  Serial.print("WiFi Sent: ");
  Serial.println(msg);
}

// ===== Send via LoRa =====
void sendLoRa(String msg) {
  LoRa.beginPacket();
  LoRa.print(msg);
  LoRa.endPacket();

  Serial.print("LoRa Sent: ");
  Serial.println(msg);
}

// ===== Setup =====
void setup() {
  Serial.begin(9600);
  esp.begin(9600);

  Wire.begin();

  // ADXL345 init
  Wire.beginTransmission(ADXL345_ADDR);
  Wire.write(0x2D);
  Wire.write(8);
  Wire.endTransmission();

  delay(1000);

  readAccelerometer();
  ax0 = ax;
  ay0 = ay;
  az0 = az;

  // LoRa init
  LoRa.setPins(SS, RST, DIO0);

  if (!LoRa.begin(433E6)) {
    Serial.println("LoRa init failed!");
    while (1);
  }

  Serial.println("SYSTEM READY (WiFi + LoRa)");
}

// ===== Loop =====
void loop() {

  int waterValue = analogRead(WATER_SENSOR);
  readAccelerometer();

  bool landslide = false;

  if (abs(ax - ax0) > 200 || 
      abs(ay - ay0) > 200 || 
      abs(az - az0) > 200) {
    landslide = true;
  }

  // ===== Decision =====
  if (waterValue > WATER_THRESHOLD) {
    statusMsg = "FLOOD";
  }
  else if (landslide) {
    statusMsg = "LANDSLIDE";
  }
  else {
    statusMsg = "NORMAL";
  }

  // ===== SEND BOTH =====
  sendWiFi(statusMsg);   // existing system
  sendLoRa(statusMsg);   // new system

  // ===== Debug Output =====
  Serial.print("Water:");
  Serial.print(waterValue);
  Serial.print(" | Acc:");
  Serial.print(ax); Serial.print(",");
  Serial.print(ay); Serial.print(",");
  Serial.print(az);
  Serial.print(" | Status:");
  Serial.println(statusMsg);

  delay(2000);
}
