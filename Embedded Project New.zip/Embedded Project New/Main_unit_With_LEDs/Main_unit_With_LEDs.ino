#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_ADXL345_U.h>
#include <SoftwareSerial.h>

SoftwareSerial esp(2, 3);

Adafruit_ADXL345_Unified accel = Adafruit_ADXL345_Unified(12345);

float x0, y0, z0;
float threshold = 0.5;

// Local (main)
bool L2 = false;
bool F2 = false;

// Received (secondary)
bool L1 = false;
bool F1 = false;

int waterPin = A0;
int waterThreshold = 400;

// LED pins
int ledLandslide = 8;
int ledFlood = 9;

void sendCommand(String cmd, int t) {
  esp.println(cmd);
  delay(t);
}

void setup() {
  Serial.begin(9600);
  esp.begin(115200);

  pinMode(ledLandslide, OUTPUT);
  pinMode(ledFlood, OUTPUT);

  accel.begin();
  accel.setRange(ADXL345_RANGE_16_G);

  delay(2000);

  sensors_event_t event;
  accel.getEvent(&event);

  x0 = event.acceleration.x;
  y0 = event.acceleration.y;
  z0 = event.acceleration.z;

  sendCommand("AT", 2000);
  sendCommand("AT+CWMODE=2", 2000);
  sendCommand("AT+CWSAP=\"MAIN_SERVER\",\"12345678\",5,3", 3000);
  sendCommand("AT+CIPMUX=1", 2000);
  sendCommand("AT+CIPSERVER=1,80", 2000);

  Serial.println("SERVER READY");
}

void loop() {

  // -------- LOCAL SENSOR --------
  sensors_event_t event;
  accel.getEvent(&event);

  float dx = abs(event.acceleration.x - x0);
  float dy = abs(event.acceleration.y - y0);
  float dz = abs(event.acceleration.z - z0);

  L2 = (dx > threshold || dy > threshold || dz > threshold);

  int waterValue = analogRead(waterPin);
  F2 = (waterValue > waterThreshold);

  // -------- RECEIVE --------
  String buffer = "";

  while (esp.available()) {
    char c = esp.read();
    buffer += c;
  }

  int start = buffer.indexOf('<');
  int end   = buffer.indexOf('>');

  if (start != -1 && end != -1) {
    String msg = buffer.substring(start + 1, end);

    if (msg.length() == 2) {
      L1 = (msg[0] == '1');
      F1 = (msg[1] == '1');
    }
  }

  // -------- LED CONTROL --------
  if (L1 && L2) {
    digitalWrite(ledLandslide, HIGH);
  } else {
    digitalWrite(ledLandslide, LOW);
  }

  if (F1 && F2) {
    digitalWrite(ledFlood, HIGH);
  } else {
    digitalWrite(ledFlood, LOW);
  }

  // -------- SERIAL OUTPUT --------
  Serial.print("L1=");
  Serial.print(L1);
  Serial.print(" F1=");
  Serial.print(F1);

  Serial.print(" | L2=");
  Serial.print(L2);
  Serial.print(" F2=");
  Serial.print(F2);

  Serial.print(" | STATUS=");

  if (L1 && L2) {
    Serial.print("LANDSLIDE");
  }
  else if (F1 && F2) {
    Serial.print("FLOOD");
  }
  else {
    Serial.print("NORMAL");
  }

  Serial.println();

  delay(1000);
}